function freelancer_freelancerscript_toggleit(obj) {
	var el = document.getElementById(obj);
	if ( el.style.display != 'none' ) {
		$('#' + obj).hide();
	}
	else {
		$('#' + obj).show();
	}
}