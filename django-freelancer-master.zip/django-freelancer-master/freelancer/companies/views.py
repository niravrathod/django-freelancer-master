# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render

from django.http import HttpResponse,Http404,HttpResponseRedirect

from django.urls import reverse

from .models import Client,Plan,Transaction

from client_project.views import post_project

from django.core.files.storage import FileSystemStorage

from freelancers.models import Freelancer,Bid

from client_project.models import Project

from django.utils import timezone

from dateutil.relativedelta import relativedelta

from django.contrib import messages

from django.conf import settings

from paypal.standard.forms import PayPalPaymentsForm

import imp
import os
import sys

from authorizenet import apicontractsv1
from authorizenet.apicontrollers import createTransactionController

# Create your views here.

def home(request):
	return render(request, 'index.html', {})


def clientprofile(request,client_id):
	try:
		user_id = int(request.session['loggedin_client'])
		if int(client_id)==int(user_id):
			data = Client.objects.get(id=int(client_id))
			if data.company_name == None or data.company_owner == None or data.company_address == None or data.company_city == None or data.company_state == None or data.company_country == None or data.company_zip_pin == None or data.company_mobile == None:
				data.email = request.POST['email']
				data.username = request.POST['username']
				data.company_name = request.POST['c_name']
				data.company_owner = request.POST['c_owner']
				data.company_address = request.POST['c_address']
				data.company_city = request.POST['c_city']
				data.company_state = request.POST['c_state']
				data.company_country = request.POST['c_country']
				data.company_zip_pin = request.POST['c_zip_pin']
				data.company_mobile = request.POST['c_mobile']
				data.company_website = request.POST['c_website']
				myfile = request.FILES['c_logo']
				fs = FileSystemStorage()
				filename = fs.save(myfile.name, myfile)
				upload_file_url = fs.url(filename)
				data.company_logo = request.FILES['c_logo']
				data.save()
				return HttpResponseRedirect(reverse(post_project,args=(int(client_id),)))
			else:
				return HttpResponseRedirect(reverse(updateprofile,args=(int(client_id),)))
		else:
			raise Http404('Invalid Client Id')
	except Exception:
		raise Http404('Invalid login')

def updateprofile(request,client_id):
	try:
		user_id = int(request.session['loggedin_client'])
		# if 'loggedin_client' in request.session and int(user_id) == client_id:
			# data = Client.objects.get(id=int(client_id))
			# return render(request, 'updateprofile.html', {'data':data})
		if 'loggedin_client' in request.session:
			if int(user_id) == int(client_id):
				data = Client.objects.get(id=int(client_id))
				if data.company_name != None and data.company_owner != None and data.company_address != None and data.company_city != None and data.company_state != None and data.company_country != None and data.company_zip_pin != None and data.company_mobile != None:
					return render(request, 'updateclientprofile.html', {'data':data})
				else:
					return render(request, 'clientprofile.html', {'data':data,'msg':'Please Complete Your Profile First!'})
			else:
				raise Http404('Invalid Client ID')
		else:
			raise Http404('Invalid Client ID')

	except Exception:
		raise Http404('Invalid login')

def updateprofilesubmit(request,client_id):
	try:
		user_id = int(request.session['loggedin_client'])
		if int(client_id)==int(user_id):
			data = Client.objects.get(id=int(client_id))
			if data.company_name != None and data.company_owner != None and data.company_address != None and data.company_city != None and data.company_state != None and data.company_country != None and data.company_zip_pin != None and data.company_mobile != None:
				
				data.email = request.POST['email']
				data.username = request.POST['username']
				data.company_name = request.POST['c_name']
				data.company_owner = request.POST['c_owner']
				data.company_address = request.POST['c_address']
				data.company_city = request.POST['c_city']
				data.company_state = request.POST['c_state']
				data.company_country = request.POST['c_country']
				data.company_zip_pin = request.POST['c_zip_pin']
				data.company_mobile = request.POST['c_mobile']
				data.company_website = request.POST['c_website']
				if request.POST.get('c_logo',False) == '':
					pass
				else:
					myfile = request.FILES['c_logo']
					fs = FileSystemStorage()
					filename = fs.save(myfile.name, myfile)
					upload_file_url = fs.url(filename)
					data.company_logo = request.FILES['c_logo']
				#request.POST['c_logo']
				data.save()
				return HttpResponseRedirect(reverse(clientprofile,args=(int(client_id),)))
			else:
				return HttpResponseRedirect(reverse(clientprofile,args=(int(client_id),)))
		else:
			raise Http404('Invalid Client Id')

	except Exception:
		raise Http404('Invalid login')

def view_all_bidders(request,client_id):
	try:
		user_id = request.session['loggedin_client']
		if 'loggedin_client' in request.session and int(user_id) == int(client_id):
			client_data = Client.objects.get(id=int(client_id))
			bid_data_check = Bid.objects.filter(clients=client_data).exists()
			if bid_data_check:
				startdate = timezone.now().date() + timezone.timedelta(days=1)
				enddate = startdate + timezone.timedelta(days=180)
				project_data = Project.objects.filter(client_id=client_data,status='True',delivery_date__range = [startdate, enddate])
				for bidders_data in project_data:
					all_data = bidders_data.freelancers.all()
					return render(request, 'view_all_bidders.html', {'client_data':client_data,'freelancers_data':all_data,'project_data':project_data})
			else:
				messages.add_message(request, messages.INFO, 'There are no bidders, Please post a project to get bidding done.')
				return HttpResponseRedirect(reverse(post_project,args=(int(client_id),)))
	except Exception:
		raise Http404('Invalid Login')

def edit_posted_project(request,client_id):
	try:
		user_id = request.session['loggedin_client']
		if 'loggedin_client' in request.session and int(user_id) == int(client_id):
			client_data = Client.objects.get(id=int(client_id))
			startdate = timezone.now().date() + timezone.timedelta(days=1)
			enddate = startdate + timezone.timedelta(days=180)
			tomorrow = timezone.now() + timezone.timedelta(days=1)
			transaction_check = Transaction.objects.filter(client_id = client_data,expiry_date__gte = tomorrow)
			project_data = Project.objects.filter(client_id=client_data,status='True',delivery_date__range = [startdate, enddate])
			project_data_not = Project.objects.filter(client_id=client_data,status='False',delivery_date__range = [startdate, enddate])
			if transaction_check:
				#active plan
				for data in project_data_not:
					data.status=True
					data.save()	
				project_data_exists = Project.objects.filter(client_id=client_data,status='True',delivery_date__range = [startdate, enddate]).exists()
				if project_data_exists:
					return render(request, 'edit_posted_project.html', {'project_data':project_data,'client_id':int(client_id)})
				else:
					messages.add_message(request, messages.INFO, 'There are no projects to edit, Please post a project.')
					return HttpResponseRedirect(reverse(post_project,args=(int(client_id),)))
			else:
				for data in project_data:
					data.status=False
					data.save()
				messages.add_message(request, messages.WARNING, 'Please purchase any one plan from below.')
				return HttpResponseRedirect(reverse(view_plans,args=(int(client_id),)))

	except Exception:
		raise Http404('Invalid Login')


def edit_selected_project(request,client_id,project_id):
	try:
		user_id = request.session['loggedin_client']
		if 'loggedin_client' in request.session and int(user_id) == int(client_id):
			client_data = Client.objects.get(id=int(client_id))
			startdate = timezone.now().date() + timezone.timedelta(days=1)
			enddate = startdate + timezone.timedelta(days=180)
			tomorrow = timezone.now() + timezone.timedelta(days=1)
			transaction_check = Transaction.objects.filter(client_id = client_data,expiry_date__gte = tomorrow)
			project_data_exists = Project.objects.filter(id=int(project_id),client_id=client_data,status='True',delivery_date__range = [startdate, enddate]).exists()
			project_data_not = Project.objects.filter(client_id=client_data,status='False',delivery_date__range = [startdate, enddate])
			if transaction_check:
				for data in project_data_not:
					data.status=True
					data.save()	
				if project_data_exists:
					project_data = Project.objects.get(id=int(project_id))
					if project_data.id == int(project_id):
							project_categories = (
							    ('BUSINESS'),
							    ('MARKETING'),
							    ('WEBSITE_DEVELOPMENT'),
							    ('DESIGN'),
							    ('WRITING'),
							    ('ACCOUNTING'),
							    ('ENGINEERING'),
							    ('MOBILE_APPLICATION'),
							    ('OTHER'),
							)
							project_date = project_data.delivery_date.date().isoformat
							return render(request, 'edit_selected_project.html', {'project_data':project_data,'project_categories':project_categories,'project_date':project_date,'client_data':client_data})
					else:
						raise Http404('Invalid Project Id')
				else:
					messages.add_message(request, messages.INFO, 'There are no projects to edit, Please post a project.')
					return HttpResponseRedirect(reverse(post_project,args=(int(client_id),)))
			else:
				for data in project_data:
					data.status=False
					data.save()
				messages.add_message(request, messages.WARNING, 'Please purchase any one plan from below.')
				return HttpResponseRedirect(reverse(view_plans,args=(int(client_id),)))

	except Exception:
		raise Http404('Invalid Login')

def edit_selected_project_submit(request,client_id,project_id):
	#try:
	user_id = request.session['loggedin_client']
	if 'loggedin_client' in request.session and int(user_id) == int(client_id):
		client_data = Client.objects.get(id=int(client_id))
		startdate = timezone.now().date() + timezone.timedelta(days=1)
		enddate = startdate + timezone.timedelta(days=180)
		tomorrow = timezone.now() + timezone.timedelta(days=1)
		transaction_check = Transaction.objects.filter(client_id = client_data,expiry_date__gte = tomorrow)
		project_data_exists = Project.objects.filter(id=int(project_id),client_id=client_data,status='True',delivery_date__range = [startdate, enddate]).exists()
		project_data_not = Project.objects.filter(client_id=client_data,status='False',delivery_date__range = [startdate, enddate])
		if transaction_check:
			for data in project_data_not:
				data.status=True
				data.save()	
			if project_data_exists:
				project_data = Project.objects.get(id=int(project_id))

				if project_data.id == int(project_id):
						project_categories = (
						    ('BUSINESS'),
						    ('MARKETING'),
						    ('WEBSITE_DEVELOPMENT'),
						    ('DESIGN'),
						    ('WRITING'),
						    ('ACCOUNTING'),
						    ('ENGINEERING'),
						    ('MOBILE_APPLICATION'),
						    ('OTHER'),
						)
						#update data
						if request.POST['project_category'] == 'OTHER':
							if request.POST.get('required_doc',False) == '':
								pass
							else:
								myfile = request.FILES['required_doc']
								fs = FileSystemStorage()
								filename = fs.save(myfile.name, myfile)
								project_data.required_doc=request.FILES['required_doc']
							project_data.project_title=request.POST['project_title']
							project_data.project_cat_list=request.POST['project_category']
							project_data.other_field=request.POST['project_categories']
							project_data.client_id=client_data
							project_data.project_budget=request.POST['project_budget']
							project_data.delivery_date=request.POST['delivery_date'] 
							project_data.status=True
							project_data.more_about=request.POST['project_desc']
							project_data.skills_required=request.POST['skills']
						else:
							if request.POST.get('required_doc',False) == '':
								pass
							else:
								myfile = request.FILES['required_doc']
								fs = FileSystemStorage()
								filename = fs.save(myfile.name, myfile)
								project_data.required_doc=request.FILES['required_doc']
							project_data.project_title=request.POST['project_title']
							project_data.project_cat_list=request.POST['project_category']
							project_data.client_id=client_data
							project_data.project_budget=request.POST['project_budget']
							project_data.delivery_date=request.POST['delivery_date'] 
							project_data.status=True
							project_data.more_about=request.POST['project_desc']
							project_data.skills_required=request.POST['skills']

							
						project_data.save()
						messages.add_message(request, messages.SUCCESS, 'Project Updated Successfully!')
						return HttpResponseRedirect(reverse(edit_selected_project,args=(client_data.id,project_data.id,)))
						#return render(request, 'edit_selected_project.html', {'project_data':project_data,'project_categories':project_categories,'project_date':project_date})
				else:
					raise Http404('Invalid Project Id')
			else:
				messages.add_message(request, messages.INFO, 'There are no projects to edit, Please post a project.')
				return HttpResponseRedirect(reverse(post_project,args=(int(client_id),)))
		else:
			for data in project_data:
				data.status=False
				data.save()
			messages.add_message(request, messages.WARNING, 'Please purchase any one plan from below.')
			return HttpResponseRedirect(reverse(view_plans,args=(int(client_id),)))

	# except Exception:
	# 	raise Http404('Invalid Login')



def view_freelancer_details(request,client_id,freelancer_id):
	#view_details_of_perticular_freelancer_or_bidder
	pass


def view_plans(request,client_id):
	try:
		user_id = request.session['loggedin_client']
		if 'loggedin_client' in request.session and int(user_id) == int(client_id):
			
			data = Client.objects.get(id=int(client_id))
			transaction_check = Transaction.objects.filter(client_id=data).exists()
			if transaction_check:
				#client has activated plan
				tomorrow = timezone.now() + timezone.timedelta(days=1)
				transaction_plan_check = Transaction.objects.filter(client_id=data,expiry_date__gte = tomorrow).exists()
				if transaction_plan_check:
					tomorrow = timezone.now() + timezone.timedelta(days=1)
					transaction_plan = Transaction.objects.get(client_id=data,expiry_date__gte = tomorrow)
					return render(request, 'view_my_plan.html', {'client_data':data,'my_plan':transaction_plan})
				else:
					#expired
					all_plans = Plan.objects.filter(plan_status='True')
					return render(request, 'view_plans.html', {'client_data':data,'all_plans':all_plans,'expired':'Your plan is expired!'})
					
				# enddate = transaction_plan.expiry_date > timezone.now()
				# if enddate:
				# 	#not expired
				# 	return render(request, 'view_my_plan.html', {'client_data':data,'my_plan':transaction_plan})
				# else:
				# 	#expired
				# 	all_plans = Plan.objects.filter(plan_status='True')
				# 	return render(request, 'view_plans.html', {'client_data':data,'all_plans':all_plans,'expired':'Your plan is expired!'})
			else:
				all_plans = Plan.objects.filter(plan_status='True')
				return render(request, 'view_plans.html', {'client_data':data,'all_plans':all_plans})
	except Exception:
		raise Http404('Invalid Login')


def select_gateway(request,client_id):
	try:
		user_id = request.session['loggedin_client']
		if 'loggedin_client' in request.session and int(user_id) == int(client_id):
			
			data = Client.objects.get(id=int(client_id))
			if data.company_name != None and data.company_owner != None and data.company_address != None and data.company_city != None and data.company_state != None and data.company_country != None and data.company_zip_pin != None and data.company_mobile != None:
				selected_plan = request.POST['plans']
				list_of_gateways = ['Authorize.Net','Paypal']
				return render(request, 'select_payment_gateway.html', {'selected_plan':selected_plan,'data':data,'list_of_gateways':list_of_gateways})    
			else:
				return render(request, 'clientprofile.html', {'data':data,'msg':'Please Complete Your Profile First!'})
	except Exception:
		raise Http404('Invalid Login')

def payment_done(request):
	return HttpResponse('Done')
	# try:
	# 	user_id = request.session['loggedin_client']
	# 	if 'loggedin_client' in request.session and int(user_id) == int(client_id):
			
	# 		data = Client.objects.get(id=int(client_id))
	# 		if data.company_name != None and data.company_owner != None and data.company_address != None and data.company_city != None and data.company_state != None and data.company_country != None and data.company_zip_pin != None and data.company_mobile != None:
	# 			return HttpResponse('Done')
	# 			# selected_plan = request.POST['plans']
	# 			# list_of_gateways = ['Authorize.Net','Paypal']
	# 			# return render(request, 'select_payment_gateway.html', {'selected_plan':selected_plan,'data':data,'list_of_gateways':list_of_gateways})    
	# 		else:
	# 			return render(request, 'clientprofile.html', {'data':data,'msg':'Please Complete Your Profile First!'})
	# except Exception:
	# 	raise Http404('Invalid Login')

def payment_cancelled(request):
	return HttpResponse('Cancelled')
	# try:
	# 	user_id = request.session['loggedin_client']
	# 	if 'loggedin_client' in request.session and int(user_id) == int(client_id):
			
	# 		data = Client.objects.get(id=int(client_id))
	# 		if data.company_name != None and data.company_owner != None and data.company_address != None and data.company_city != None and data.company_state != None and data.company_country != None and data.company_zip_pin != None and data.company_mobile != None:
	# 			return HttpResponse('Cancelled')
	# 			# selected_plan = request.POST['plans']
	# 			# list_of_gateways = ['Authorize.Net','Paypal']
	# 			# return render(request, 'select_payment_gateway.html', {'selected_plan':selected_plan,'data':data,'list_of_gateways':list_of_gateways})    
	# 		else:
	# 			return render(request, 'clientprofile.html', {'data':data,'msg':'Please Complete Your Profile First!'})
	# except Exception:
	# 	raise Http404('Invalid Login')


def plansubmit(request,client_id):
	# try:
	user_id = request.session['loggedin_client']
	if 'loggedin_client' in request.session and int(user_id) == int(client_id):
		
		data = Client.objects.get(id=int(client_id))
		if data.company_name != None and data.company_owner != None and data.company_address != None and data.company_city != None and data.company_state != None and data.company_country != None and data.company_zip_pin != None and data.company_mobile != None:

			if request.POST['submit'] == 'Select':
				selected_plan = request.POST['plans']
				if request.POST['gateway'] == 'Authorize.Net':
					return render(request, 'credit_card_info.html', {'selected_plan':selected_plan,'data':data})
				elif request.POST['gateway'] == 'Paypal':
					host = request.get_host()
					get_data = Plan.objects.get(plan_desc=selected_plan)
					amount = get_data.plan_price
					paypal_dict={
					    	'business':settings.PAYPAL_RECEIVER_EMAIL,
					    	'amount':amount,
					    	'plan_name':selected_plan,
					    	'currency_code':'USD',
					    	'notify_url':'http://{}{}'.format(host, reverse('paypal-ipn')),
					    	'return_url':'http://{}{}'.format(host, reverse('payment_done')),
					    	'cancel_return':'http://{}{}'.format(host, reverse('payment_cancelled')),
					    }
					plan_price = str(paypal_dict['amount'])
					plan_price1=int(plan_price)/60
					form = PayPalPaymentsForm(initial=paypal_dict)
					context = {"form": form,"plan_price1":plan_price1}
					return render(request, "pay_with_paypal.html", context)
					#return render(request, 'pay_with_paypal.html', {'selected_plan':selected_plan,'data':data})
				else:
					raise Http404('Gateway Not Found')
			else:
				raise Http404('Invalid plan')

		else:
			return render(request, 'clientprofile.html', {'data':data,'msg':'Please Complete Your Profile First!'})
	# except Exception:
	# 	raise Http404('Invalid Login')

def makepayment(request,client_id):
	try:
		user_id = request.session['loggedin_client']
		if 'loggedin_client' in request.session and int(user_id) == int(client_id):
			
			data = Client.objects.get(id=int(client_id))
			if data.company_name != None and data.company_owner != None and data.company_address != None and data.company_city != None and data.company_state != None and data.company_country != None and data.company_zip_pin != None and data.company_mobile != None:
				if request.POST['submit'] == 'Make Payment':
					selected_plan = request.POST['selected_plan']
					get_data = Plan.objects.get(plan_desc=selected_plan)
					amount = get_data.plan_price

					merchantAuth = apicontractsv1.merchantAuthenticationType()
					merchantAuth.name = '4b56NChmmRE'
					merchantAuth.transactionKey = '4qLE3S38r3632Qd5'
					creditCard = apicontractsv1.creditCardType()
				 	creditCard.cardNumber = request.POST['card_number']
				 	creditCard.expirationDate = request.POST['exp_date']
				 	creditCard.cardCode = request.POST['card_code']
				    
				   	payment = apicontractsv1.paymentType()
				   	payment.creditCard = creditCard

				    # Create order information
					order = apicontractsv1.orderType()
					order.invoiceNumber = "10101"
					order.description = get_data.plan_desc

				    # Set the customer's Bill To address
					customerAddress = apicontractsv1.customerAddressType()
					customerAddress.firstName = "Ellen"
					customerAddress.lastName = "Johnson"
					customerAddress.company = "Souveniropolis"
					customerAddress.address = "14 Main Street"
					customerAddress.city = "Pecan Springs"
					customerAddress.state = "TX"
					customerAddress.zip = "44628"
					customerAddress.country = "USA"

					# Set the customer's identifying information
					customerData = apicontractsv1.customerDataType()
					customerData.type = "individual"
					customerData.id = "99999456654"
					customerData.email = "EllenJohnson@example.com"

					# Add values for transaction settings
					duplicateWindowSetting = apicontractsv1.settingType()
					duplicateWindowSetting.settingName = "duplicateWindow"
					duplicateWindowSetting.settingValue = "600"
					settings = apicontractsv1.ArrayOfSetting()
					settings.setting.append(duplicateWindowSetting)

					# setup individual line items
					line_item_1 = apicontractsv1.lineItemType()
					line_item_1.itemId = str(get_data.id)
					line_item_1.name = "first"
					line_item_1.description = "Here's the first line item"
					line_item_1.quantity = "1"
					line_item_1.unitPrice = str(get_data.plan_price)

					# build the array of line items
					line_items = apicontractsv1.ArrayOfLineItem()
					line_items.lineItem.append(line_item_1)

					# Create a transactionRequestType object and add the previous objects to it.
					transactionrequest = apicontractsv1.transactionRequestType()
					transactionrequest.transactionType = "authCaptureTransaction"
					transactionrequest.amount = amount
					transactionrequest.payment = payment
					transactionrequest.order = order
					transactionrequest.billTo = customerAddress
					transactionrequest.customer = customerData
					transactionrequest.transactionSettings = settings
					transactionrequest.lineItems = line_items

					# Assemble the complete transaction request
					createtransactionrequest = apicontractsv1.createTransactionRequest()
					createtransactionrequest.merchantAuthentication = merchantAuth
					createtransactionrequest.refId = "MerchantID-0001"
					createtransactionrequest.transactionRequest = transactionrequest
					# Create the controller
					createtransactioncontroller = createTransactionController(
					    createtransactionrequest)
					createtransactioncontroller.execute()

					response = createtransactioncontroller.getresponse()
					if response is not None:
				        # Check to see if the API request was successfully received and acted upon
						if response.messages.resultCode == "Ok":
				            # Since the API request was successful, look for a transaction response
				            # and parse it to display the results of authorizing the card
							if hasattr(response.transactionResponse, 'messages') is True:
								print 'Successfully created transaction with Transaction ID: %s'% response.transactionResponse.transId
								print 'Transaction Response Code: %s' %response.transactionResponse.responseCode
								print 'Message Code: %s' %response.transactionResponse.messages.message[0].code
								print 'Description: %s' % response.transactionResponse.messages.message[0].description
								print transactionrequest.amount
								if get_data.plan_desc=='Basic_Monthly':
									exp_date = timezone.now().date() + relativedelta(months=1)
									insert_data = Transaction.objects.create(client_id=data,plan_id=get_data,active_date=timezone.now(),expiry_date=exp_date)
								elif get_data.plan_desc=='Basic_Yearly':
									exp_date = timezone.now().date() + relativedelta(years=1)
									insert_data = Transaction.objects.create(client_id=data,plan_id=get_data,active_date=timezone.now(),expiry_date=exp_date)
								elif get_data.plan_desc=='Advanced_Monthly':
									exp_date = timezone.now().date() + relativedelta(months=1)
									insert_data = Transaction.objects.create(client_id=data,plan_id=get_data,active_date=timezone.now(),expiry_date=exp_date)
								elif get_data.plan_desc=='Advanced_Yearly':
									exp_date = timezone.now().date() + relativedelta(years=1)
									insert_data = Transaction.objects.create(client_id=data,plan_id=get_data,active_date=timezone.now(),expiry_date=exp_date)
								insert_data.save()
								project_categories = (
								    ('BUSINESS'),
								    ('MARKETING'),
								    ('WEBSITE_DEVELOPMENT'),
								    ('DESIGN'),
								    ('WRITING'),
								    ('ACCOUNTING'),
								    ('ENGINEERING'),
								    ('MOBILE_APPLICATION'),
								    ('OTHER'),
								)
								messages.add_message(request, messages.SUCCESS, 'Your Plan Successfully Activated!')
								return HttpResponseRedirect(reverse('post_project',args=(data.id,)))
								# return render(request, 'post_project.html', {'data': data,'project_categories':project_categories,'plan_activated':'Your Plan Successfully Activated!'})
							else:
								print 'Failed Transaction.'
				                if hasattr(response.transactionResponse, 'errors') is True:
				                    print 'Error Code:  %s' % str(response.transactionResponse.errors.error[0].errorCode)
				                    print 'Error message: %s' %response.transactionResponse.errors.error[0].errorText
				        # Or, print errors if the API request wasn't successful
				        else:
				            print 'Failed Transaction.'
				            if hasattr(response, 'transactionResponse') is True and hasattr(
				                    response.transactionResponse, 'errors') is True:
				                print 'Error Code: %s' % str(response.transactionResponse.errors.error[0].errorCode)
				                print 'Error message: %s' %response.transactionResponse.errors.error[0].errorText
				            else:
				            	print 'Error Code: %s' %response.messages.message[0]['code'].text
				            	print 'Error message: %s' %response.messages.message[0]['text'].text
					messages.add_message(request, messages.WARNING, 'Invalid Credit Card Details')
					return HttpResponseRedirect(reverse(view_plans,args=(data.id,)))
					#return HttpResponse(get_data)
					# return render(request, 'credit_card_info.html', {'selected_plan':selected_plan,'data':data})    
				else:
					return render(request, 'clientprofile.html', {'data':data,'msg':'Please Complete Your Profile First!'})
			else:
				raise Http404('Please Try Again')
	except Exception:
		raise Http404('Invalid Login')
	
