# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

# Create your models here.

class Client(models.Model):
	email = models.EmailField()
	username = models.CharField(max_length=255)
	password = models.CharField(max_length=255)
	company_name = models.CharField(max_length=255,null=True,blank=True)
	company_owner = models.CharField(max_length=255,null=True,blank=True)
	company_address = models.TextField(max_length=255,null=True,blank=True)
	company_city = models.CharField(max_length=255,null=True,blank=True)
	company_state = models.CharField(max_length=255,null=True,blank=True)
	company_country = models.CharField(max_length=255,null=True,blank=True)
	company_zip_pin = models.CharField(max_length=255,null=True,blank=True)
	company_mobile = models.CharField(max_length=255,null=True,blank=True)
	company_website = models.CharField(max_length=255,blank=True,null=True)
	company_logo = models.ImageField(upload_to = 'images/company/', default = 'images/company/co.png')


	def __str__(self):
		return self.email

class Plan(models.Model):
	plan_name = models.CharField(max_length=255,null=True,blank=True)
	plan_price = models.BigIntegerField(null=True,blank=True)
	plan_desc = models.CharField(max_length=255,null=True,blank=True) #month,year
	plan_status = models.BooleanField('Plan_Status',default=False)#active/inactive

	def __str__(self):
		return self.plan_desc

class Transaction(models.Model):
	client_id = models.ForeignKey(Client,on_delete=models.CASCADE,null=True,blank=True)
	plan_id = models.ForeignKey(Plan,on_delete=models.CASCADE,null=True,blank=True)
	active_date = models.DateTimeField('Active_Date',null=True,blank=True)
	expiry_date = models.DateTimeField('Expiry_Date',null=True,blank=True) #-1 day

