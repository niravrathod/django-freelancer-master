# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

from freelancers.models import Freelancer

from companies.models import Client

from django.core.validators import FileExtensionValidator

from django import forms

# Create your models here.
class Project(models.Model):
	project_categories = (
    ('BUSINESS','Business'),
    ('MARKETING','Marketing'),
    ('WEBSITE_DEVELOPMENT','Website_Development'),
    ('DESIGN','Design'),
    ('WRITING','Writing'),
    ('ACCOUNTING','Accounting'),
    ('ENGINEERING','Engineering'),
    ('MOBILE_APPLICATION','Mobile_Application'),
    ('OTHER','Other'),
)
	project_cat_list = models.CharField(max_length=255,choices=project_categories)
	other_field = models.CharField(max_length=255,null=True,blank=True)
	client_id = models.ForeignKey(Client, on_delete = models.CASCADE,null=True)
	freelancers = models.ManyToManyField(Freelancer,null=True,blank=True)
	project_title = models.CharField(max_length=255,null=True,blank=True)
	project_budget = models.IntegerField(null=True,blank=True)
	started_date = models.DateTimeField(auto_now_add = True, auto_now = False,null=True,blank=True)
	delivery_date = models.DateTimeField('Date Delivered',null=True,blank=True)
	status = models.BooleanField(default=False)
	created_at = models.DateTimeField(auto_now_add = True, auto_now = False,null=True,blank=True)
	updated_at = models.DateTimeField(auto_now_add = False, auto_now = True,null=True,blank=True)
	more_about = models.TextField(max_length=255,null=True,blank=True)
	required_doc = models.FileField(upload_to='docs/', validators=[FileExtensionValidator(allowed_extensions=['pdf','docx','doc'])],null=True,blank=True)

	skills_required = models.CharField(max_length=255,null=True,blank=True)

	def __str__(self):
		return self.project_title





