# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render,get_object_or_404,redirect

from django.http import Http404,HttpResponse

from companies.models import Client,Transaction,Plan

from companies.views import *

from .models import Project

from django.utils import timezone

from django.core.files.storage import FileSystemStorage

# Create your views here.

def post_project_home(request):
	# user_id = int()
	# freelancer_id = int()
	if not 'loggedin_client' in request.session or 'loggedin_freelancer' in request.session:
		return HttpResponseRedirect(reverse('signup'))
	else:
		return HttpResponseRedirect(reverse(post_project,args=(request.session['loggedin_client'],)))

def post_project(request,client_id):
	try:
		user_id = int(request.session['loggedin_client'])
		if int(user_id) == int(client_id):
			if request.session.has_key('loggedin_client'):
				project_categories = (
				    ('BUSINESS'),
				    ('MARKETING'),
				    ('WEBSITE_DEVELOPMENT'),
				    ('DESIGN'),
				    ('WRITING'),
				    ('ACCOUNTING'),
				    ('ENGINEERING'),
				    ('MOBILE_APPLICATION'),
				    ('OTHER'),
				)
				data = get_object_or_404(Client, id=int(client_id))
				tomorrow = timezone.now() + timezone.timedelta(days=1)
				transaction_check = Transaction.objects.filter(client_id=data,expiry_date__gte=tomorrow).exists()
				if data.company_name == None or data.company_owner == None or data.company_address == None or data.company_city == None or data.company_state == None or data.company_country == None or data.company_zip_pin == None or data.company_mobile == None:
					return render(request, 'clientprofile.html', {'data': data,'msg':'Please Complete Your Profile First!'})
				elif not transaction_check:
					return HttpResponseRedirect(reverse('view_plans',args=(data.id,)))

				elif transaction_check:
					tomorrow = timezone.now() + timezone.timedelta(days=1)
					transaction_plan = Transaction.objects.get(client_id=data,expiry_date__gte = tomorrow)
					enddate = transaction_plan.expiry_date > timezone.now()
					if not enddate:
						#expired
						all_plans = Plan.objects.filter(plan_status='True')
						return render(request, 'view_plans.html', {'client_data':data,'all_plans':all_plans,'expired':'Your plan is expired!'})
					else:
						return render(request, 'post_project.html', {'data': data,'project_categories':project_categories})
				else:
					return render(request, 'post_project.html', {'data': data,'project_categories':project_categories})
			else:
				raise Http404('Invalid User Id')
		else:
			return redirect('../signup/')
	except Exception:
		raise Http404('Invalid Login')
def post_project_submit(request,client_id):
	try:
		user_id = request.session['loggedin_client']
		if 'loggedin_client' in request.session and int(client_id) == int(user_id):
			if request.POST['submit'] == 'Submit':
				project_categories = (
				    ('BUSINESS'),
				    ('MARKETING'),
				    ('WEBSITE_DEVELOPMENT'),
				    ('DESIGN'),
				    ('WRITING'),
				    ('ACCOUNTING'),
				    ('ENGINEERING'),
				    ('MOBILE_APPLICATION'),
				    ('OTHER'),
				)
				data = Client.objects.get(id=int(client_id))
				tomorrow = timezone.now() + timezone.timedelta(days=1)
				transaction_check = Transaction.objects.filter(client_id=data,expiry_date__gte=tomorrow).exists()
				if data.company_name == None or data.company_owner == None or data.company_address == None or data.company_city == None or data.company_state == None or data.company_country == None or data.company_zip_pin == None or data.company_mobile == None:
					return render(request, 'clientprofile.html', {'data': data,'msg':'Please Complete Your Profile First!'})
				elif not transaction_check:
					return HttpResponseRedirect(reverse('view_plans',args=(data.id,)))
				elif transaction_check:
					tomorrow = timezone.now() + timezone.timedelta(days=1)
					transaction_plan = Transaction.objects.get(client_id=data,expiry_date__gte = tomorrow)
					enddate = transaction_plan.expiry_date > timezone.now()
					if not enddate:
						#expired
						all_plans = Plan.objects.filter(plan_status='True')
						return render(request, 'view_plans.html', {'client_data':data,'all_plans':all_plans,'expired':'Your plan is expired!'})
					else:
						if request.POST['project_category'] == 'OTHER':
							myfile = request.FILES['required_doc']
							fs = FileSystemStorage()
							filename = fs.save(myfile.name, myfile)
							project_data = Project.objects.create(project_title=request.POST['project_title'],project_cat_list=request.POST['project_category'],other_field=request.POST['project_categories'],client_id=data,project_budget=request.POST['project_budget'],delivery_date=request.POST['delivery_date'],status=True,more_about=request.POST['project_desc'],skills_required=request.POST['skills'],required_doc=request.FILES['required_doc'])
						else:
							myfile = request.FILES['required_doc']
							fs = FileSystemStorage()
							filename = fs.save(myfile.name, myfile)
							project_data = Project.objects.create(project_title=request.POST['project_title'],project_cat_list=request.POST['project_category'],client_id=data,project_budget=request.POST['project_budget'],delivery_date=request.POST['delivery_date'],status=True,more_about=request.POST['project_desc'],skills_required=request.POST['skills'],required_doc=request.FILES['required_doc'])
						project_data.save()
						return render(request, 'post_project.html', {'data': data,'project_categories':project_categories,'success':'Project Successfully Posted!'})
					#return HttpResponse('Done')
			else:
				raise Http404('Invalid User Id')
		else:
			raise Http404('Invalid Login')
	except Exception:
		raise Http404('Invalid Login')