# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

from companies.models import Client


# Create your models here.

class Freelancer(models.Model):
	email = models.EmailField()
	username = models.CharField(max_length=255)
	password = models.CharField(max_length=255)
	name = models.CharField(max_length=255,null=True,blank=True)
	gender = models.CharField(max_length=255,null=True,blank=True)
	address = models.TextField(max_length=255,null=True,blank=True)
	city = models.CharField(max_length=255,null=True,blank=True)
	state = models.CharField(max_length=255,null=True,blank=True)
	country = models.CharField(max_length=255,null=True,blank=True)
	zip_pin = models.CharField(max_length=255,null=True,blank=True)
	mobile = models.CharField(max_length=255,null=True,blank=True)
	website = models.CharField(max_length=255,blank=True,null=True)
	skills = models.CharField(max_length=255,null=True,blank=True)
	profile_pic = models.ImageField(upload_to = 'images/freelancers/', default = 'images/freelancers/co.png')
	about_yourself = models.TextField(max_length=255,null=True,blank=True)

	def __str__(self):
		return self.email

from client_project.models import Project

class Bid_budget(models.Model):
	freelancer_id = models.ForeignKey(Freelancer,on_delete=models.CASCADE,null=True,blank=True)
	project_id = models.ForeignKey(Project,on_delete=models.CASCADE,null=True,blank=True)
	budget =  models.BigIntegerField(null=True,blank=True)
	timeperiod = models.DateTimeField('Within Time Period',null=True,blank=True)
	def __str__(self):
		return 'Freelancer Email: ' + str(self.freelancer_id) + '  Project Name: ' + str(self.project_id) + ' Bid_Budget: ' + str(self.budget) + ' Within_Time_Period: ' + str(self.timeperiod)
		

class Bid(models.Model):
	freelancer_id = models.ForeignKey(Freelancer,on_delete=models.CASCADE,null=True,blank=True)
	clients = models.ManyToManyField(Client,null=True,blank=True)
	projects = models.ManyToManyField(Project,null=True,blank=True)
	date_created = models.DateTimeField('Date Created',null=True,blank=True)
	date_update = models.DateTimeField(auto_now_add=True,auto_now=False,null=True,blank=True)
	bid_budget = models.ManyToManyField(Bid_budget,null=True,blank=True)

	def __str__(self):
		return 'Freelancer Email: ' + str(self.freelancer_id)
