"""freelancer URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.11/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import url,include
from django.contrib import admin

from . import views

urlpatterns = [
    #url(r'^$', views.home, name='home'),
    url(r'^(?P<freelancer_id>[0-9]+)/profile/$', views.profile, name='profile'),
    url(r'^(?P<freelancer_id>[0-9]+)/profilesubmit/$', views.profilesubmit, name='profilesubmit'),
    url(r'^(?P<freelancer_id>[0-9]+)/profileupdate/$', views.profileupdate, name='profileupdate'),
    url(r'^(?P<freelancer_id>[0-9]+)/profileupdatesubmit/$', views.profileupdatesubmit, name='profileupdatesubmit'),
    url(r'^(?P<freelancer_id>[0-9]+)/browse_projects/$', views.browse_projects, name='browse_projects'),
    url(r'^(?P<freelancer_id>[0-9]+)/browse_projects/$', views.browse_projects, name='browse_projects'),
    url(r'^(?P<freelancer_id>[0-9]+)/(?P<project_id>[0-9]+)/bid/$', views.bid, name='bid'),
    url(r'^(?P<freelancer_id>[0-9]+)/(?P<project_id>[0-9]+)/bidsubmit/$', views.bidsubmit, name='bidsubmit'),
    url(r'^(?P<freelancer_id>[0-9]+)/bid_history/$', views.bid_history, name='bid_history'),
    url(r'^(?P<freelancer_id>[0-9]+)/(?P<project_id>[0-9]+)/bid_history/update_cost/$', views.update_bid_cost, name='update_bid_cost'),
    url(r'^(?P<freelancer_id>[0-9]+)/(?P<project_id>[0-9]+)/bid_history/update_cost/submit/$', views.update_bid_cost_submit, name='update_bid_cost_submit'),


]
