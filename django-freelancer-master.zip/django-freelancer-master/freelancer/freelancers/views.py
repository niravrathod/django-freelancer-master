# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render

from django.http import HttpResponse,HttpResponseRedirect,Http404

from django.urls import reverse

from .models import Freelancer,Bid,Bid_budget

from client_project.models import Project

from django.utils import timezone

from django.core.files.storage import FileSystemStorage

# Create your views here.


def browse_projects(request,freelancer_id):
	try:
		user_id = request.session['loggedin_freelancer']
		if int(user_id) == int(freelancer_id):
			startdate = timezone.now().date() + timezone.timedelta(days=1)
			enddate = startdate + timezone.timedelta(days=180)
			project_data = Project.objects.filter(status='True',delivery_date__range = [startdate, enddate])
			return render(request, 'freelancerhome.html', {'project_data':project_data,'freelancer_id':freelancer_id})
		else:
			raise Http404('Invalid Id')
	except Exception:
		raise Http404('Invalid login')

def profile(request,freelancer_id):
	try:
		user_id = int(request.session['loggedin_freelancer'])
		if int(freelancer_id)==int(user_id):
			data = Freelancer.objects.get(id=int(freelancer_id))
			if data.name == None or data.address == None or data.city == None or data.state == None or data.country == None or data.zip_pin == None or data.mobile == None or data.skills == None or data.about_yourself == None:
				data.email = request.POST['email']
				data.username = request.POST['username']
				data.name = request.POST['name']
				data.address = request.POST['address']
				data.skills = request.POST['skills']
				data.about_yourself = request.POST['about']
				data.city = request.POST['city']
				data.state = request.POST['state']
				data.country = request.POST['country']
				data.zip_pin = request.POST['zip_pin']
				data.mobile = request.POST['mobile']
				data.website = request.POST['website']
				data.profile_pic = request.POST['profilepic']
				data.save()
				return HttpResponseRedirect(reverse(browse_projects,args=(int(freelancer_id),)))
			else:
				return HttpResponseRedirect(reverse(profileupdate,args=(int(freelancer_id),)))
		else:
			raise Http404('Invalid Client Id')

	except Exception:
		raise Http404('Invalid Client Id')


def profileupdate(request,freelancer_id):
	try:
		user_id = int(request.session['loggedin_freelancer'])
		if 'loggedin_freelancer' in request.session:
			if int(user_id) == int(freelancer_id):
				data = Freelancer.objects.get(id=int(freelancer_id))
				if data.name != None or data.address != None or data.city != None or data.state != None or data.country != None or data.zip_pin != None or data.mobile != None or data.skills != None or data.about_yourself != None:
					return render(request, 'freelancerprofileupdate.html', {'data':data})
				else:
					return render(request, 'freelancerprofile.html', {'data':data,'msg':'Please Complete Your Profile First!'})
			else:
				raise Http404('Invalid User ID')
		else:
			raise Http404('Invalid User ID')

	except Exception:
		raise Http404('Invalid User ID')


def profileupdatesubmit(request,freelancer_id):
	try:
		user_id = int(request.session['loggedin_freelancer'])
		if int(freelancer_id)==int(user_id):
			data = Freelancer.objects.get(id=int(freelancer_id))
			if data.name != None or data.address != None or data.city != None or data.state != None or data.country != None or data.zip_pin != None or data.mobile != None or data.skills != None or data.about_yourself != None:


				data.email = request.POST['email']
				data.username = request.POST['username']
				data.name = request.POST['name']
				data.address = request.POST['address']
				data.skills = request.POST['skills']
				data.about_yourself = request.POST['about']
				data.city = request.POST['city']
				data.state = request.POST['state']
				data.country = request.POST['country']
				data.zip_pin = request.POST['zip_pin']
				data.mobile = request.POST['mobile']
				data.website = request.POST['website']
				if request.POST.get('profilepic',False) == '':
					pass
				else:
					myfile = request.FILES['profilepic']
					fs = FileSystemStorage()
					filename = fs.save(myfile.name, myfile)
					upload_file_url = fs.url(filename)
					data.profile_pic = request.FILES['profilepic']
				data.save()
				return HttpResponseRedirect(reverse(profile,args=(int(freelancer_id),)))
			else:
				return HttpResponseRedirect(reverse(profile,args=(int(freelancer_id),)))
		else:
			raise Http404('Invalid Client Id')
	except Exception:
		raise Http404('Invalid Client Id')



def profilesubmit(request,freelancer_id):
	try:	
		user_id = request.session['loggedin_freelancer']
		if 'loggedin_freelancer' in request.session and int(user_id) == int(freelancer_id):
			data = Freelancer.objects.get(id=int(freelancer_id))
			if data.name == None or data.address == None or data.city == None or data.state == None or data.country == None or data.zip_pin == None or data.mobile == None or data.skills == None or data.about_yourself == None:
				data.email = request.POST['email']
				data.username = request.POST['username']
				data.name = request.POST['name']
				data.address = request.POST['address']
				data.skills = request.POST['skills']
				data.about_yourself = request.POST['about']
				data.city = request.POST['city']
				data.state = request.POST['state']
				data.country = request.POST['country']
				data.zip_pin = request.POST['zip_pin']
				data.mobile = request.POST['mobile']
				data.website = request.POST['website']
				myfile = request.FILES['profilepic']
				fs = FileSystemStorage()
				filename = fs.save(myfile.name, myfile)
				upload_file_url = fs.url(filename)
				data.profile_pic = request.FILES['profilepic']
				data.save()
				return HttpResponseRedirect(reverse(browse_projects,args=(int(freelancer_id),)))
			else:
				return HttpResponseRedirect(reverse(profileupdate,args=(int(freelancer_id),)))
		else:
			raise Http404('Invalid User Id')
	except Exception:
		raise Http404('Invalid User Id')


def bid(request,freelancer_id,project_id):
	try:
		user_id = request.session['loggedin_freelancer']
		if 'loggedin_freelancer' in request.session and int(user_id) == int(freelancer_id):
			data = Freelancer.objects.get(id=int(freelancer_id))
			if data.name == None or data.address == None or data.city == None or data.state == None or data.country == None or data.zip_pin == None or data.mobile == None or data.skills == None or data.about_yourself == None:
				return render(request, 'freelancerprofile.html', {'data':data,'msg':'Please Complete Your Profile First!'})
			# elif data.email == freelancers.email and a:
			# 	return HttpResponse('already done')
			else:
				#return HttpResponse('Bid')
				project_data = Project.objects.get(id=int(project_id))
				return render(request, 'bid_details.html', {'project_data':project_data,'data':data,'project_id':int(project_id)})
		else:
			raise Http404('Invalid User ID')
	except Exception:
		raise Http404('Invalid Login')

def bidsubmit(request,freelancer_id,project_id):
	#add count to main project table by adding freelancer_data to freelancers
	#select bid table where freelancer_id is this
	#add client_data to clients in bid table by using project_id to project table
	#add projects in bid table by using main project table
	#add date_created from NOW
	#add bid_budget from user input
	#add bid_timeperiod from user input

	try:
		user_id = request.session['loggedin_freelancer']
		if 'loggedin_freelancer' in request.session and int(user_id) == int(freelancer_id):
			data = Freelancer.objects.get(id=int(freelancer_id))
			if data.name == None or data.address == None or data.city == None or data.state == None or data.country == None or data.zip_pin == None or data.mobile == None or data.skills == None or data.about_yourself == None:
				return render(request, 'freelancerprofile.html', {'data':data,'msg':'Please Complete Your Profile First!'})
			else:
				if request.POST['submit'] == 'Bid':
					freelancer_data = Freelancer.objects.get(id=int(freelancer_id))
					project_data = Project.objects.get(id=int(project_id))

					bid_data_exists = Bid.objects.filter(freelancer_id=freelancer_data).exists()

					#bid_data_project_exists = Bid.objects.filter(projects=project_data).exists()

					bid_data_project_exists = project_data.freelancers.filter(id=freelancer_data.id).exists()

					if bid_data_exists and not bid_data_project_exists:
						project_data.freelancers.add(freelancer_data)
						bid_data = Bid.objects.get(freelancer_id=freelancer_data)
						bid_data.projects.add(project_data)
						bid_data.clients.add(project_data.client_id)
						bid_budget_data = Bid_budget.objects.create(freelancer_id=freelancer_data,project_id=project_data,budget=request.POST['bid_budget'],timeperiod=request.POST['bid_timeperiod'])

						bid_budget_data.save()
						bid_data.bid_budget.add(bid_budget_data)
					elif bid_data_exists and bid_data_project_exists:
						#return HttpResponseRedirect(reverse(browse_projects,args=(int(freelancer_id),)))
						startdate = timezone.now().date() + timezone.timedelta(days=1)
						enddate = startdate + timezone.timedelta(days=180)
						project_data_all = Project.objects.filter(status='True',delivery_date__range = [startdate, enddate])
						return render(request, 'freelancerhome.html', {'project_data':project_data_all,'freelancer_id':int(freelancer_id),'done_already':'You Have Already Bid On This Project!'})
					else:
						project_data.freelancers.add(freelancer_data)
						bid_data = Bid.objects.create(freelancer_id=freelancer_data,date_created=timezone.now())

						bid_budget_data = Bid_budget.objects.create(freelancer_id=freelancer_data,project_id=project_data,budget=request.POST['bid_budget'],timeperiod=request.POST['bid_timeperiod'])

						bid_budget_data.save()

						bid_data.projects.add(project_data)
						bid_data.bid_budget.add(bid_budget_data)

						bid_data.clients.add(project_data.client_id)
					project_data.save()
					bid_data.save()
					#return HttpResponseRedirect(reverse(browse_projects,args=(int(freelancer_id),)))
					startdate = timezone.now().date() + timezone.timedelta(days=1)
					enddate = startdate + timezone.timedelta(days=180)
					project_data_all = Project.objects.filter(status='True',delivery_date__range = [startdate, enddate])
					return render(request, 'freelancerhome.html', {'project_data':project_data_all,'freelancer_id':int(freelancer_id),'success':'Your Bid Success On This Project!'})
				else:
					raise Http404('Please Try Again!')
	except Exception:
		raise Http404('Invalid Login')


def bid_history(request,freelancer_id):
	try:
		user_id = request.session['loggedin_freelancer']
		if 'loggedin_freelancer' in request.session and int(user_id) == int(freelancer_id):
			data = Freelancer.objects.get(id=int(freelancer_id))
			startdate = timezone.now().date() + timezone.timedelta(days=1)
			enddate = startdate + timezone.timedelta(days=180)
			# project_data = Project.objects.filter(client_id=client_data,status='True',delivery_date__range = [startdate, enddate])
			project_data_exists = Project.objects.filter(freelancers=data,status='True',delivery_date__range = [startdate, enddate]).exists()
			if project_data_exists:
				project_data = Project.objects.filter(freelancers=data,status='True',delivery_date__range = [startdate, enddate])
				bid_data = Bid.objects.filter(freelancer_id=data)
				for bids_data in bid_data:
					startdate = timezone.now().date() + timezone.timedelta(days=1)
					enddate = startdate + timezone.timedelta(days=180)
					bid_budget_data = bids_data.projects.filter(status='True',delivery_date__range = [startdate, enddate])
					freelancer_bid_budget = bids_data.bid_budget.filter(freelancer_id=data)
					return render(request, 'bid_history.html', {'bid_budget_data':bid_budget_data,'project_data':project_data,'data':data,'freelancer_bid_budget':freelancer_bid_budget})
			else:
				startdate = timezone.now().date() + timezone.timedelta(days=1)
				enddate = startdate + timezone.timedelta(days=180)
				project_data_all = Project.objects.filter(status='True',delivery_date__range = [startdate, enddate])
				return render(request, 'freelancerhome.html', {'project_data':project_data_all,'freelancer_id':int(freelancer_id),'History_error':'There Is No History To Show!'}) 
		else:
			raise Http404('Invalid User ID')
	except Exception:
		raise Http404('Invalid Login')

def update_bid_cost(request,freelancer_id,project_id):
	try:
		user_id = request.session['loggedin_freelancer']
		if 'loggedin_freelancer' in request.session and int(user_id) == int(freelancer_id):
			data = Freelancer.objects.get(id=int(freelancer_id))
			startdate = timezone.now().date() + timezone.timedelta(days=1)
			enddate = startdate + timezone.timedelta(days=180)
			project_data_exists = Project.objects.filter(freelancers=data,status='True',delivery_date__range = [startdate, enddate]).exists()
			if project_data_exists:
				startdate = timezone.now().date() + timezone.timedelta(days=1)
				enddate = startdate + timezone.timedelta(days=180)
				project_data = Project.objects.get(id=int(project_id),status='True',delivery_date__range = [startdate, enddate])
				bid_budget_data = Bid_budget.objects.filter(freelancer_id=data,project_id=project_data)
				for budget in bid_budget_data:
					all_budget = budget.budget
					return render(request, 'update_cost.html', {'bid_budget_data':bid_budget_data,'project_data':project_data,'data':data,'budgets':all_budget})
			else:
				startdate = timezone.now().date() + timezone.timedelta(days=1)
				enddate = startdate + timezone.timedelta(days=180)
				project_data_all = Project.objects.filter(status='True',delivery_date__range = [startdate, enddate])
				return render(request, 'freelancerhome.html', {'project_data':project_data_all,'freelancer_id':int(freelancer_id),'History_error':'There Is No History To Show!'}) 
		else:
			raise Http404('Invalid User ID')
	except Exception:
		raise Http404('Invalid Login')

def update_bid_cost_submit(request,freelancer_id,project_id):
	try:
		user_id = request.session['loggedin_freelancer']
		if 'loggedin_freelancer' in request.session and int(user_id) == int(freelancer_id):
			data = Freelancer.objects.get(id=int(freelancer_id))
			project_data_exists = Project.objects.filter(freelancers=data).exists()
			if project_data_exists:
				project_data = Project.objects.get(id=int(project_id))
				bid_budget_data = Bid_budget.objects.get(project_id=project_data)
				if request.POST['submit'] == 'Update Cost For %s'%project_data.project_title:
					bid_budget_data.budget = request.POST['cost_update']
					bid_budget_data.save()
					return HttpResponseRedirect(reverse(bid_history,args=(int(freelancer_id),)))
				else:
					raise Http404('Invalid User ID')
			else:
				startdate = timezone.now().date() + timezone.timedelta(days=1)
				enddate = startdate + timezone.timedelta(days=180)
				project_data_all = Project.objects.filter(status='True',delivery_date__range = [startdate, enddate])
				return render(request, 'freelancerhome.html', {'project_data':project_data_all,'freelancer_id':int(freelancer_id),'History_error':'There Is No History To Show!'}) 
		else:
			raise Http404('Invalid User ID')
	except Exception:
		raise Http404('Invalid Login')

	
