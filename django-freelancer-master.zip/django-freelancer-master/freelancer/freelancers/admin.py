# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin

from .models import Freelancer,Bid,Bid_budget

# Register your models here.

admin.site.register(Freelancer)
admin.site.register(Bid)
admin.site.register(Bid_budget)

