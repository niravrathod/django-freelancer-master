# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render

from freelancers.models import Freelancer

from companies.models import Client

from django.http import HttpResponseRedirect

from django.urls import reverse

from client_project.models import Project

from django.utils import timezone

# Create your views here.

def home(request):
	return render(request, 'home.html', {})

def signup(request):
	return render(request, 'signup.html', {})

def signupsubmit(request):
	if request.POST['submit'] == 'Sign Up':
		if request.POST['acctype'] == '1':
			data = Freelancer.objects.create(
					email = request.POST['user_email'], 
					username = request.POST['user_username'], 
					password = request.POST['user_password'],
					gender = request.POST['gender']
					)
			data.save()
			return render(request, 'login.html', {'success':'Account Created!'})

			#freelancer

		elif request.POST['acctype'] == '2':
			data = Client.objects.create(
					email = request.POST['user_email'], 
					username = request.POST['user_username'], 
					password = request.POST['user_password']
					)
			data.save()
			return render(request, 'login.html', {'success':'Account Created!'})

			#client	
		else:
			#error
			return render(request, 'signup.html', {'radioerror':'Please choose account type!'})
		
	else:
		return render(request, 'signup.html', {})

def login(request):
	if 'loggedin_client' in request.session:
		return render(request, 'clienthome.html', {})
	elif 'loggedin_freelancer' in request.session:
		startdate = timezone.now().date() + timezone.timedelta(days=1)
		enddate = startdate + timezone.timedelta(days=180)
		freelancer_id = request.session['loggedin_freelancer']
		project_data = Project.objects.filter(status='True',delivery_date__range = [startdate, enddate])
		return render(request, 'freelancerhome.html', {'project_data':project_data,'freelancer_id':freelancer_id})
	else:
		return render(request, 'login.html', {})


def loginsubmit(request):
	if 'loggedin_freelancer' in request.session:
		startdate = timezone.now().date() + timezone.timedelta(days=1)
		enddate = startdate + timezone.timedelta(days=180)
		project_data = Project.objects.filter(status='True',delivery_date__range = [startdate, enddate])
		freelancer_id = request.session['loggedin_freelancer']
		return render(request, 'freelancerhome.html', {'project_data':project_data,'freelancer_id':freelancer_id})
	elif 'loggedin_client' in request.session:
		return render(request, 'clienthome.html', {})	
	elif request.POST.get('submit',False) == 'Login':
		if request.POST.get('acctype',False) == '1':
			#return render(request, 'login.html', {'a_error': 'Invalid Login!!'})
			if Freelancer.objects.filter(username = request.POST['l_username']).exists() and Freelancer.objects.filter(password = request.POST['l_password']).exists():
				for username in Freelancer.objects.filter(username = request.POST['l_username']):
						request.session['loggedin_freelancer'] = username.id
				startdate = timezone.now().date() + timezone.timedelta(days=1)
				enddate = startdate + timezone.timedelta(days=180)
				project_data = Project.objects.filter(status='True',delivery_date__range = [startdate, enddate])
				freelancer_id = request.session['loggedin_freelancer']
				return render(request, 'freelancerhome.html', {'project_data':project_data,'freelancer_id':freelancer_id})
			else:
				return render(request, 'login.html', {'a_error': 'Invalid Login!'})
		
		elif request.POST.get('acctype',False) == '2':
			if Client.objects.filter(username = request.POST['l_username']).exists() and Client.objects.filter(password = request.POST['l_password']).exists():
				for username in Client.objects.filter(username = request.POST['l_username']):
					request.session['loggedin_client'] = username.id
				return render(request, 'clienthome.html', {})
			else:
				return render(request, 'login.html', {'a_error': 'Invalid Login!'})
		else:
			return render(request, 'login.html', {'a_error': 'Invalid Login!'})


	else:
		return render(request, 'login.html', {})


def logout(request):
	if 'loggedin_client' in request.session:
		del request.session['loggedin_client']
		return HttpResponseRedirect(reverse(home))

	elif 'loggedin_freelancer' in request.session:
		del request.session['loggedin_freelancer']
		return HttpResponseRedirect(reverse(home))

	else:
		return HttpResponseRedirect(reverse(home))


